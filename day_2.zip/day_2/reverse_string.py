str = input()
str1=""
def reverse():
    len=len(str)
    for i in range(0,len+1):
       str1[len+1]=str[i]
       

print(str1[0:])
