#include<stdio.h>
#include<string.h>
main()
{
	char str[100],str1[100];
	gets(str);
	short i,j,len;
	len=strlen(str);
	for(i=len-1,j=0;i>0,j<len;i--,j++)
	{
		switch(str[i]){
		
			case 'A'...'Z' :
			{
			str1[i]=str[j];
			break;
			}
			case 'a'...'z':
				{
			str1[i]=str[j];
			break;
			}	
	
					}
		
	}
	puts(str1);
		
}
