l=list(map(int,input().split()))
'''
for i in l:
    print('*'*i)

'''
'''
for i in range(len(l)):
    for j in range(max(l)-l[i]):
        print('-',end=" ")
    for k in range(l[i]):
        print('*',end=" ")
    print()
'''

for i in range(max(l),0,-1):
    print(f"{i:2d}|",end="")
    for j in l:
        if j>=i:
            print('.',end="")
        else:
            print(" ",end="")
    print()
        

