l=list(map(int,input().split()))#l=2 4 6 7 8 10
target=int(input())#tar=13
i=0
j=0
cursum=l[0]
while j<len(l)-1:
    if cursum==target:
        print(i,j,cursum)
        break
    elif cursum>target:
        cursum-=l[i]
        i+=1
    else:
        j+=1
        cursum+=l[j]
        
