def func(l,target):
    i=0
    j=1
    while i<len(l) and j<len(l):
        if l[i]+l[j]==target:
            return i,j
        i+=1
        j+=1
l=list(map(int,input().split()))
target=int(input())
print(func(l,target))
