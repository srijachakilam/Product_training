#stack implementation

import collections
stack=collections.deque()
stack.append()
stack.pop()
