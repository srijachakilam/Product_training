#include<stdio.h>
long long int factorial(long long int);
long long int n,fact;
main()
{
	scanf("%lld",&n);
	fact=factorial(n);
	printf("%lld",fact);
}
long long int factorial(long long int n)
{
	if(n==0 || n==1)
	return n;
	else
	return(n*factorial(n-1));
}
