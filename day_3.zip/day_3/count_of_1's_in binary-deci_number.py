n=int(input())
s=[]
while(n>0):
    x=n%2
    n=n//2
    s.append(x)
s.reverse()
#print(s)
count=0
for i in s:
    if(i==1):
        count=count+1
        #print(count)
print(count)
