#check whether the i th bit in the result is 1 or not
#the result is a logical and (1 left shift i-1)

a=int(input())
i=int(input())
if(a&(1<<(i-1))):
    print('yes')
else:
    print('no')
