n=int(input())
s=[]
for i in range(0,n):
    x=int(input())
    s.append(x)
print(s)
b=max(s)
print(b)
for i in range(0,b):
    if i not in s:
        print(i)
