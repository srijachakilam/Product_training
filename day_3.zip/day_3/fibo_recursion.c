#include<stdio.h>
long long int fibo(long long int);
long long int n;
main()
{
	int i;
	long int n;
	scanf("%lld",&n);
	for(i=0;i<n;i++)
	printf("%lld  ",fibo(i));
}
long long int fibo(long long int n)
{
	if(n==0 || n==1)
	return n;
	else
	return (fibo(n-1)+fibo(n-2));
	
}
