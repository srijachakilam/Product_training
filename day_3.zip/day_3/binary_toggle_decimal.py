n=int(input())
pos=int(input())
s=[]
while(n>0):
    x=n%2
    n=n//2
    s.append(x)
s.reverse()
print(s)
#print(s[pos])
if(s[pos]==0):
    s[pos]=1
elif(s[pos]==1):
    s[pos]=0
print(s)
su=0
l=len(s)
m=l-1
#print(l)
for i in s:
    a=(2**m)*i
    su=su+a
    m=m-1
print(su)
    

