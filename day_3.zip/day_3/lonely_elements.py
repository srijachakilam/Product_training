n=int(input())
s=[]
for i in range(0,n):
    x=int(input())
    s.append(x)
for i in s:
    for j in i:
        if(j==j+1):
            break
        else:
            print(j)
