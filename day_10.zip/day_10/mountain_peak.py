def peak(l,si,li):
    while(si<=li):
        mid=(si+li)//2
        if l[mid]>l[mid-1] and l[mid]>l[mid+1]:
            return mid
        elif l[mid-1]>l[mid]:
            li=mid
        else:
            si=mid+1
    
l=list(map(int,input().split()))
print(peak(l,0,len(l)-1))
