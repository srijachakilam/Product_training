#binary_sqrt(loops):
def sq(n,si,li,floor):
    while si<=li:
        mid= (si+li)//2
        sq=mid*mid
        if sq==n:
            floor=mid
            break
        elif sq<n:
            floor=mid
            si=mid+1
        else:
            li=mid-1
    return floor


#binary_sqrt(recursion):

def sqr(n,si,li,floor):
    if n==0 or n==1:
        return n
    if n<0:
        return -1
    if si<=li:
        mid=(si+li)//2
        sq=mid*mid
        if sq==n:
            return mid
        elif sq<n:
            floor=mid
            return sqr(n,mid+1,li,floor)
        else :
            return sqr(n,si,mid-1,floor)
    return floor

#binary_sqrt(exact value)
def sqrt_bs(n,epsilon=1e-6):
    if n<0:
        raise ValueError("cannot compete the square")
    if n<1:
        left,right=n,1
    else:
        left,right=0,n
    while abs(left-right)>epsilon:
        mid=(left+right)/2
        mid_sq=mid*mid
        if mid_sq<n:
            left=mid
        else:
            right=mid
    return (left+right)/2
n=int(input())
si=0
li=n//2
floor=-1
print('sqrt_recursion:',sqr(n,si,li,floor))
print('sqrt_loops:',sq(n,si,li,floor))
print('Exact square root:',sqrt_bs(n))
        
    
