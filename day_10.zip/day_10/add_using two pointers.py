def add(l,lo,hi,tar):
        if lo>hi:
            return -1
        if l[lo]+l[hi]==tar:
            return lo,hi
        if l[lo]+l[hi]<tar:
                return add(l,lo+1,hi,tar)
        if l[lo]+l[hi]>tar:
                return add(l,lo,hi-1,tar)
    
l=list(map(int,input().split()))
n=int(input())
print(add(l,0,len(l)-1,n))
