import turtle
s=turtle.Turtle()
#s.forward(100)
#s.right(90)
s.forward(100)
s.clear()
s.reset()
for i in range(4):
    s.forward(100)
    s.right(90)
s.clear()
s.reset()
s.speed(0)#speed is fast
turtle.bgcolor("black")
s.color("yellow")
for i in range(10):
    s.circle(90)
    s.right(36)
s.speed(1)#speed is slow
s.color("red")
for i in range(10):
    s.circle(100)
    s.circle(105)
    s.circle(110)
    s.circle(115)
    s.right(36)
