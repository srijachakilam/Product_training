#print from 1 to n:func
#print from n to 1:func1
def func(n):
    if n==0:
        return
    func(n-1)
    print(n)

def func1(n):
    if n==0:
        return
    print(n)
    func1(n-1)

n=int(input())
func(n)
func1(n)
