# for loops
'''def palin(s):
    l=len(s)
    for i in s:
        if(i!=s[l-1]):
            return 0
        l=l-1    
    return 1    

s=input('enter the string')
x=palin(s)
if x==1:
    print('palindrome')
else:
    print('not palindrome')
'''

# while loops
'''s=input()
i=0
j=len(s)-1
while(i<j):
    if s[i]!=s[j]:
        print('not palindrome')
        break
    i+=1
    j-=1
else:
    print('palindrome')
'''


#recursion
def palin(l,s,i):
    if i>l:
       return 1
    if(s[i]!=s[l]):
        return 0
    return palin(l-1,s,i+1)

s=input('enter string')
l=len(s)-1
i=0
x=palin(l,s,i)
if x==0:print('not')
else:print('yes')
