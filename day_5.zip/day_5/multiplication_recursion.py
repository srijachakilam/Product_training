#multiplication
def multi(n,r):
    if(r==0):
        return
    multi(n,r-1)
    print(n,'*',r,'=',n*r)

n=int(input('enter the number'))
r=int(input(''))
multi(n,r)
            
