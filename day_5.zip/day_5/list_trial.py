l=[]
n=len(l)
for i in range(n+1):
    x=int(input())
    l.append(x)
print(l)
