from itertools import combinations
def subset(n,arr,x):
    for i in range(n+1):
        for j in combinations(arr,i):
            if sum(j)==x:
                print(list(j))
n=int(input())
arr=[]
for i in range(n):
    m=int(input())
    arr.append(m)
x=int(input())
subset(n,arr,x)


#input:1, 5, 6, 3, 7
#input:10
#output:True
'''
from itertools import combinations
def subset(arr,tar):
    for i in range(len(arr)+1):
        for j in combinations(arr,i):
            if sum(j)==tar:
                return True



l=[]
nums=(input().split(','))
for i in nums:
      l.append(int(i))
target=int(input())
print(subset(l,target))
'''
