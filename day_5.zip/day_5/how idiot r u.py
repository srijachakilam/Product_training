import random
a=input('how idiot are you:')
print(random.randint(1,100),'%')
