def pointer(nums,l,i,r):
    while i<=r:
        if nums[i]==0:
            nums[l],nums[i]=nums[i],nums[l]
            l+=1
            i+=1
        elif nums[i]==1:
            i+=1
        elif nums[i]==2:
            nums[i],nums[r]=nums[r],nums[i]
            r-=1
    return nums
nums=list(map(int,input().split(',')))
'''l=0
i=0
r=len(nums)-1
'''
print(pointer(nums,0,0,len(nums)-1))
