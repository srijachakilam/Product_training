nums=list(map(int,input().split()))
n=[]
l=0
r=len(nums)-1
count=0
for i in range(len(nums)-1):
    n.append(nums[i])
    mnums=nums[(i+1):]
    #print(mnums)
    lm=max(n)
    rm=max(mnums)
    #print(i,':',lm)
    #print(i,':',rm)
    f=min(lm,rm)
    #print(i,':',f)
    if f>nums[i]:
        count+=(f-nums[i])
    #print(count)
print(count)
