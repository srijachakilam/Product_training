n=int(input())
wt=list(map(int,input().split()))
pr=list(map(int,input().split()))
l=list(zip(wt,pr))
l.sort(key=lambda x:x[1]/x[0],reverse=True)
maxpr=0
for weight,profit in l:
    if weight<=n:
        maxpr+=profit
        n-=weight
    else:
        maxpr+=n*(profit/weight)
        break
print(maxpr)
        
