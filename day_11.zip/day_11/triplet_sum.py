def triplet(l,t):
    for i in range(len(l)):
        for j in range(i+1,len(l)):
            for k in range(j+1,len(l)):
                if l[i]+l[j]+l[k]==target:
                    return l[i],l[j],l[k]
l=list(map(int,input().split()))
target=int(input())
res=[]
print(triplet(l,target))
                
                
                    
