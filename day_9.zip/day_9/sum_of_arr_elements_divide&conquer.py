# sum of array elements using recursion
def su(l,lo,hi):
    if lo==hi:
        return l[lo]
    if lo>hi:
        return -1
    mid=(lo+hi)//2
    return su(l,lo,mid)+su(l,mid+1,hi)
l=list(map(int,input().split()))
print(su(l,0,len(l)-1))
