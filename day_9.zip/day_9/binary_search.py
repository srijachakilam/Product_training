#binary search

def searching(lo,hi,l,se):
    mid = (lo+hi)//2
    if lo>hi:
        return -1
    if l[mid]==se:
        return mid
    if l[mid]<se:
        return searching(mid+1,hi,l,se)
    if l[mid]>se:
        return searching(lo,mid-1,l,se)

        
l=list(map(int,input().split()))
'''l=[]
n=int(input())
for i in range(n):
    x=int(input())
    l.append(x)
'''
search=int(input())
x=searching(0,len(l)-1,l,search)
if x==-1:
    print('no found')
else:
    print(x)
