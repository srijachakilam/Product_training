#max of an array using divide&conquer

def maxi(l,lo,hi):
    if lo>hi:
        return -1
    if lo==hi:
        return l[lo]
    mid=(lo+hi)//2
    return max(maxi(l,lo,mid), maxi(l,mid+1,hi))
l=list(map(int,input().split()))
print(maxi(l,0,len(l)-1))
