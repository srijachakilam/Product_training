def generate_parentheses(n):
    def backtrack(s, left, right):
        if len(s) == 2 * n:
            valid_parentheses.append(s)
            return
        if left < n:
            backtrack(s + '(', left + 1, right)
        if right < left:
            backtrack(s + ')', left, right + 1)

    valid_parentheses = []
    backtrack('', 0, 0)
    return valid_parentheses

# Example usage:
n = 3  # Replace this with your desired number of pairs
parentheses_list = generate_parentheses(n)
for i in parentheses_list:
    print(i,end="")
#print(parentheses_list)
