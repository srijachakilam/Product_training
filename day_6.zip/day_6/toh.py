cou=0
def toh(n,src,aux,dest):
    global cou
    if n==1:
        cou+=1
        return 
    toh(n-1,src,dest,aux)
    cou=cou+1
    #print('disk',n,'movedfrom',src,'to',dest)
    toh(n-1,aux,src,dest)
n=int(input())
s,a,d='a','b','c'
toh(n,s,a,d)
print(cou)

'''

count = 0
def hanoi(disks, source, auxiliary, target):
  global count
  if disks == 1:
    count = count + 1
    return
 
  hanoi(disks - 1, source, target, auxiliary)
  count = count + 1
  hanoi(disks - 1, auxiliary, source, target)
 
 
disks = int(input('Enter number of disks: '))
hanoi(disks, 'A', 'B', 'C')
print("Minimum number of disks move: ", count)
'''



