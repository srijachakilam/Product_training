def check(expr):
    stack=[]
    for i in expr:
        if i in ["[","(","{"]:
            stack.append(i)

        else:
            if not stack:  #if stack is empty print false #if the first to be inserted is closing then print false
                return False
            current=stack.pop()
            if current =='(':
                if i !=")":
                    return False

            if current =='{':
                if i !="}":
                    return False

            if current =='[':
                if i !="]":
                    return False

    if stack:   #if stack is not empty print false #if there are any elements left in stack print false
        return False
    return True
expr=input()
print(check(expr))
