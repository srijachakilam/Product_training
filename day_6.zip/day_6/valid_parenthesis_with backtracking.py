l=[]
res=[]
def backtrack(n,open=0,close=0):
    if open==close==n:
        res.append("".join(l))
    if(open<n):
        l.append('(')
        backtrack(n,open+1,close)
        #print('$')
        l.pop()
    if(close<open):
        l.append(')')
        backtrack(n,open,close+1)
        #print('#')
        l.pop()
    return res
n=int(input())
print(backtrack(n))
