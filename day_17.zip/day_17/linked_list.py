#basic linked list
'''
class node:
    def __init__(self,val=0):
        self.val=val
        self.next=None
o1=node(1)
o2=node(2)
o3=node(3)
o1.next=o2
o2.next=o3
print(o1,o2,o3,sep="\n")

oa=node(10)
oa.next=node(20)#direct creating nodes without creating objects
oa.next.next=node(30)
print(oa.val,oa.next.val,oa.next.next.val)
'''

class node:
    def __init__(self,val=0):
        self.val=val
        self.next=None
class sll:
    def __init__(self):
        self.head=None
    def insertb(self,data):#insert at begin
        if self.head==None:
            self.head=node(data)
        else:
            new=node(data)
            new.next=self.head
            self.head=new
    
    def inserte(self,data):#insert at end
        if self.head==None:
            self.head=node(data)
        else:
            curr=self.head
            while(curr.next):
                curr=curr.next
            new=node(data)
            curr.next=new
    def deleteb(self):#delete at beginning
        if self.head==None:
            return
        temp=self.head
        self.head=self.head.next
        temp.next=None
        return temp.val
    def deletee(self):#delete at end
        if self.head==None:
            return
        temp=self.head
        while(temp.next.next):
            temp=temp.next

        temp1=temp.next.val
        temp.next=None
        return temp1
    def insertp(self,data,pos):#insert at position
        if self.head==None:
            self.head=node(data)
        else:
            new=node(data)
            temp=self.head
            pos-=1
            while(pos!=1):
                temp=temp.next
                pos-=1
            new.next=temp.next
            temp.next=new
    def deletep(self,pos):#delete at position
        if self.head==None:
            return
        else:
            temp=self.head
            pos-=2
            while(pos!=1):
                temp=temp.next
                pos-=1
            temp1=temp.next.val
            temp.next=temp.next.next
            return temp1
    def rev(self):
      prev=None
      curr=self.head
      while curr!=None:
          next=curr.next
          curr.next=prev
          prev=curr
          curr=next
      self.head=prev

        
    def print(self):#display
        temp=self.head
        while(temp):
            print(temp.val,end="-->")
            temp=temp.next
        
        
l=[1,2,3,4,5]
l1=[10,20,30,40]
o=sll()
for i in l:
    o.insertb(i)

for j in l1:
    o.inserte(j)
o.print()
print("\n",o.deleteb())
print("\n",o.deletee())
print("\n",o.deletep(4))
#pos=int(input())
#o.insertp(100,pos)
o.print()
print()
o.rev()
o.print()


        
