#inheritance in class
class inheritance:
    def func1(self):
        print("hello")
    def func2(self):
        print("srija")

class a1(inheritance):#hierarchical
    def func3(self):
        print("welcome")
class a2(inheritance):#hierarchical
    def func4(self):
        print("chakilam")

class a3(a1):#single,multilevel
    def func5(self):
        print("multilevel")


# create the obj for child class rather than parent class


#obj1=a1()    # no need to create an obj for a1 bze a3 is the child of a1
#obj1.func3()
#obj1.func1()
#obj1.func2()

obj2=a2()
obj2.func4()
obj2.func1()
obj2.func2()
# obj2.func3() # not in class a2 to access

obj3=a3()
obj3.func5()
obj3.func3()
obj3.func1()
obj3.func2()
#obj3.func4() #dont execute because it is in class a2 
