class magic:
    def magic_prime(self,n):
        isprime(n)
        m=reversed(n)
        isprime(m)
        if(isprime(n)== isprime(m)):
            print("magical primes")
        else:
            print("not magical primes")
    def isprime(n):
        count=0
        for i in range(1,n+1):
            if(n%i==0):
                count=count+1
        if(count>2):
            return True
        else:
            return False


obj=magic()
n=int(input())
obj.magic_prime(n)


def neon_num(n):
    x=n**2
    while(len(x)<2):
        m=n%10
        sum=sum+m
        n=n/10
    if(n==sum):
        print("neon number")
    else:
        print("not a neon")
