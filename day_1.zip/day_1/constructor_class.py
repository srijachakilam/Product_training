class inherit:
    def __init__(mango):  #constructor no need to call it again by creating an object, it will be called by interpreter implicitly
        print("default constructor")# default constructor
    def __init__(mango1,mango2):
        print("2 parameter", mango2)#parameterized constructor
    def __bank__(self):
        print("Test 1")
    def bank1(parameter):
        print("Test 2")
    def bank2(wgl):
        print("Test 3")
#obj1=inherit()
obj=inherit(120)
obj.bank1()
obj.bank2()
obj.__bank__()

