n=int(input())
'''for i in range(n):
    for j in range(n-i):
        print(" ",end='')
    for k in range(i+1):
        print("*",end=' ')
    print()

'''
for i in range(n):
    print(" "*(n-i) + "* "*(i+1))

for i in range(n):
    print(" "*(i+1) + "* "*(n-i))
