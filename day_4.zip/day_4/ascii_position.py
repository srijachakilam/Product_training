a=input()
b=ord(a)
if b>66 and b<91:
    print(b-64)
elif b>96 and b<123:
    print(b-96)
