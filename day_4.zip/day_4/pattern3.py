
'''#nrml pattern
n=int(input())
for i in range(1,n+1):
    print(str(i)*i)
  '''

n=int(input())
for i in range(1,n+1):
    b=((10**i)//9)*i
    print(b)
