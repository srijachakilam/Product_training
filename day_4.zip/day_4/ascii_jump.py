#input:Z,2 output:B
a=input()
b=int(input())
if(a.isupper()):
    c=(ord(a)+b)
    if(c>90):
        c-=26
    print(chr(c))
else:
    c=((ord(a)+b))
    if(c>122):
        c-=26
    print(chr(c))
