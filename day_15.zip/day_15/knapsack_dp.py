def knapsack(capa,wt,pr,n):
    dp=[[0 for i in range(capa+1)] for j in range(n+1)]
    for i in range(n+1):
        for w in range(capa+1):
            if w==0 or i==0:
                dp[i][w]=0
            elif wt[i-1]<=w:
                dp[i][w]=max(pr[i-1]+dp[i-1][w-wt[i-1]],dp[i-1][w-wt[i-1]])
            else:
                dp[i][w]=dp[i-1][w]
        return dp[n][w]

wt=list(map(int,input().split()))
pr=list(map(int,input().split()))
capa=int(input())
print(knapsack(capa,wt,pr,len(pr)))
