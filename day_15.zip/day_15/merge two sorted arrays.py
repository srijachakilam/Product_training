l1=list(map(int,input().split()))
l2=list(map(int,input().split()))
l=[]
i=j=k=0
while i <= len(l1) and j<=len(l2):
    if l1[i]<=l2[j]:
        l[k]=l1[i]
        k+=1
        i+=1
    else:
        l[k]=l2[j]
        k+=1
        j+=1
print(l)
