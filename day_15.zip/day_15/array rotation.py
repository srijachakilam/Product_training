#Array rotation(right to left):
'''
l=list(map(int,input().split()))
k=int(input())
for i in range(k):
    temp=l[-1]
    for j in range(len(l)-1,0,-1):
        l[j]=l[j-1]
    l[0]=temp
print(l)
        
'''

#with builtin functions(right to left):
'''
l=list(map(int,input().split()))
k=int(input())
for i in range(k):
    l.insert(0,l.pop())
print(l)
'''


#with slicing(right to left):
'''
l=list(map(int,input().split()))
k=int(input())
a=len(l)-k
l[:]=l[a:]+l[:a]
print(l)
'''
#Array rotation(left to right):
'''
l=list(map(int,input().split()))
k=int(input())
for i in range(k):
    temp=l[0]
    for j in range(len(l)-1):
        l[j]=l[j+1]
    l[-1]=temp
print(l)
'''

#with builtin functions(left to right):
'''
l=list(map(int,input().split()))
k=int(input())
for i in range(k):
    l.append(l.pop(0))
print(l)
'''

#with slicing(left to right):
l=list(map(int,input().split()))
k=int(input())
l[:]=l[k:]+l[:k]
print(l)
