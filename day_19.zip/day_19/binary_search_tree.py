#binary tree:
class node:
    def  __init__(self,val=0):
        self.val=data
        self.right=None
        self.left=None
class tree:
    def __init__(self):
        self.root=None
    def inser(self,root,val):
        if root==None:
            root=node(val)
            return root
        elif val<root.val:
            root.left=inser(root.left,val)
        elif val>root.val:
            new=node(val)
            root.right=inser(new)
    def printing(self):
        l=[]
        def pre(root):
            if root==None:
                return
            l.append(root)
            pre(root.left)
            pre=(root.right)
        return l

ob=tree()
l1=[1,2,3,4,5]
for i in l1:
    ob.inser(i)
ob.printing()
            
        
        
