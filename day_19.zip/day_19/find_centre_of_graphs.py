#input:[[1,2],[2,3],[4,2]]
#output:2
#find the centre of the graph i.e., find the common element
edges=[]
while 1:
    s=input()
    if s=='':
        break
    edges.append(list(map(int,s.split())))
for i,j in edges:
    if i in edges[1]:
        flag= i
    else:
        flag= j
print(flag)


'''
edges=
k=int(input())
if edges[0][0]==edges[1][0] or edges[0][0]==edges[1][1]:
    print edges[0][0]
else:
print edges[0][1]
'''
