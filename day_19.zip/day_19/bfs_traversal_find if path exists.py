#graph traversal:bfs
n=3
flag=0
edges=[[0,1],[1,2],[2,0]]
source=int(input())
destination=int(input())
d={0:[1,2],1:[0,2],2:[0,1]}
q=[source]
vis=set()
while q:
    a=q.pop()
    for i in d[a]:
        if i==destination:
            flag=1
        if i not in vis:
            q.append(i)
            vis.add(i)


print(flag)
