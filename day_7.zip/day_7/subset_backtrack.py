'''
#input: 3,2,12,24,5,10
#output: 24
def subset(n,tar):
    def check(start,sum):
        if sum==tar:
            return True
        if sum>tar or start==len(n):
            return False
        if check(start+1,sum+n[start]):
            subset.append(n[start])
            return True
        return check(start+1,sum)
        

    subset=[]
    if check(0,0):
        return True ,subset
    else:
        return False,[]
n=[1,2,3,4,5]
target=9
bool,subset=subset(n,target)
if bool:
    print('subset with sum',target,'exists:',subset)
else:
    print('no subset with sum',target,'exists.')
    
#print(check(l,target))
'''
#print all the subsets in array

def func(l,tar):
    def backtrack(start,s,subset):
        if s==tar:
            res.append(subset[:])
            return
        if s>target or start==len(l):
            return
        subset.append(l[start])
        backtrack(start+1,s+l[start],subset)
        subset.pop()
        backtrack(start+1,s,subset)
    res=[]
    backtrack(0,0,[])
    return res
l=list(map(int,input().split()))
target=int(input())
result=func(l,target)
if result:
    for i in result:
        print(i)
else:
    print('NO subset')


